Creating AWS EC2 instance
.TF file in Terraform folder

spun up EC2 instance-Ubuntu-T2.micro.
[created, IAM user group, provisioned access key and secerity keys and .pem file]
 Installed jenkins in EC2-
 using:
 EC2 Instance Connect (browser-based SSH connection) Ubuntu
 Configured Jenkins:
 http://100.26.177.39:8080/
 configured Jenkins job for:{}
 http://100.26.177.39:8080/job/nodejs_projec/configure
 integrated with git project:
 https://github.com/jakerella/node-unit-tests.git
 accomidated this job to trigger the build when changes made in github
 created test display job for nodejs test:
 http://100.26.177.39:8080/job/node_test/
 
 installed docker on EC2 instance and spin up master and target containes:
 
 installed docker images and provisioned nginx web application:
 
 http://100.26.177.39:8082/
 http://100.26.177.39:8081/
 
                  NAMES
e3795072db28        nginxdemos/hello:latest   "nginx -g 'daemon of…"   About an hour ago   Up About an hour    0.0.0.
0:8082->80/tcp   nginx-hello
cccc33dcb6f2        nginx:latest              "/docker-entrypoint.…"   About an hour ago   Up About an hour    0.0.0.
0:8081->80/tcp   nginx-test
7af3d584e24f        ubuntu                    "/bin/bash"              8 hours ago         Up 8 hours                
                 target2
77d2d9338ac2        ubuntu                    "/bin/bash"              8 hours ago         Up 8 hours                
                 target1
ac43a42ad771        ubuntu                    "/bin/bash"              8 hours ago         Up 8 hours                
                 ansible_master
root@ip-172-31-58-50:/etc/docker# 

Installed nginx:
yaml file in the Terraform folder

Spun up nginx using docker inage on EC2
docker run --name install_nginx.yaml -p 80:82 -d nginx
